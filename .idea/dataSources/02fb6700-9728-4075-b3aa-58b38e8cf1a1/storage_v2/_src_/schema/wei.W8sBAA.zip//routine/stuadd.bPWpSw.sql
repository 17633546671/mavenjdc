create
    definer = root@`%` procedure stuadd(IN n varchar(30), IN isgood bit, IN sex enum ('男', '女'), IN age tinyint,
                                        IN address varchar(100), IN money double, IN brith date, IN dept varchar(50))
begin
    insert stu values (null,n,isgood,sex,age,address,money,brith,dept);
end;

