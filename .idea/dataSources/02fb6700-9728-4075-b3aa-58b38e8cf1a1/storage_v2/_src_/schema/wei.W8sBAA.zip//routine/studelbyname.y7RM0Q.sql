create
    definer = root@`%` procedure studelbyname(IN n varchar(50))
begin
    delete from st where name like concat('%',n,'%');
end;

