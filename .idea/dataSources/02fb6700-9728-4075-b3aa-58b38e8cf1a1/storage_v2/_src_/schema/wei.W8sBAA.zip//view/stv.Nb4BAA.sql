create definer = root@`%` view stv as
select `st`.`id`               AS `id`,
       `st`.`sname`            AS `sname`,
       `st`.`gender`           AS `gender`,
       ifnull(`t`.`tname`, '') AS `ifnull(tname,'')`
from (`wei`.`xues` `st`
         left join `wei`.`teacher` `t` on ((`st`.`teacher_id` = `t`.`id`)));

