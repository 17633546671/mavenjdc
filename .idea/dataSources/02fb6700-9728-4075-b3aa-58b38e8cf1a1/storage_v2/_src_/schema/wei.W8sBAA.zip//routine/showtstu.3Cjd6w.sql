create
    definer = root@`%` procedure showtstu()
begin
select id,name ,dept from sta order by id desc ;
end;

